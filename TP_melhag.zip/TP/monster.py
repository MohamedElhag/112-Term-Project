import pygame

class Monster(pygame.sprite.Sprite):
    def __init__(self,x,y,speed, power):
        pygame.sprite.Sprite.__init__(self)
        self.x, self.y = x, y
        self.dx = speed
        self.dy = speed
        self.size = (75,50)
        self.health = 60
        self.power = power
        image = pygame.image.load('images/GoblinA.png')
        self.rect = pygame.Rect(x,y,*(60,60))
        rows, cols = 4,3
        width, height = image.get_size()
        cellWidth, cellHeight = width / cols, height / rows
        Monster.images = []
        for i in range(rows):
            for j in range(cols):
                try:
                    subImage = image.subsurface(
                        (i * cellHeight, j * cellWidth, cellWidth, cellHeight))
                    Monster.images.append(subImage)
                except: continue
        self.image = pygame.transform.scale(Monster.images[0], self.size)
    
    def update(self, dx, dy, dt):
        # if dx == -self.dx:
        #     self.image = pygame.transform.flip(self.image, True, False)
        # else: 
        #     self.image = pygame.transform.scale(Monster.images[1], self.size)
        self.x += dx
        self.y += dy
        self.rect.x += dx
        self.rect.y +=dy

class Boss(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.x = x
        self.y = y
        self.rect = pygame.Rect(self.x,self.y,120,120)
        self.dx, self.dy = 5, 5
        self.size = (120,120)
        self.health = 1000
        self.power = 2
        self.step = 0
        self.timer = 0
        self.pic = 'images/boss1.png'
        self.image = pygame.transform.scale(pygame.image.load('images/boss%s.png'%(self.step%9+1)), (120,120))

    def update(self, dx, dy, dt):
        if self.timer%1==0:
            self.step+=1
        self.image = pygame.transform.scale(pygame.image.load('images/boss%s.png'%(self.step%9+1)), (120,120))
        self.x += dx
        self.y += dy
        self.rect.x += dx
        self.rect.y +=dy




import pygame

class Item(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.open = False
        self.x, self.y = x, y
        self.image = pygame.transform.scale(pygame.image.load('images/closedChest.png'), (40,30))
        if self.open==True:
            self.image = pygame.transform.scale(pygame.image.load('images/openChest.png'), (40,30))
        self.rect = pygame.Rect(x,y,50,35)
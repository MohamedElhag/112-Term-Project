import pygame


class Grass(pygame.sprite.Sprite):
    def __init__(self, x, y, file, size):
        pygame.sprite.Sprite.__init__(self)
        self.x, self.y, self.image = x, y, file
        self.size = size
        self.rect = pygame.Rect(x, y, *size)


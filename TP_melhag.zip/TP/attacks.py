import pygame

class Attack(pygame.sprite.Sprite):
    def __init__(self, x, y, dir):
        self.dir = dir
        self.x = x
        self.y = y

class Heal(Attack):
    time = 50
    effect = []
    def __init__(self, user):
        #super(x, y, dir).__init__()
        pygame.sprite.Sprite.__init__(self)
        self.timeOnScreen = 0
        self.image = pygame.transform.scale(pygame.image.load('images/sparkle.png').convert_alpha(), (50,50))
        self.rect = pygame.Rect(user.x,user.y,50,50)
        Heal.effect.append(self)

    def heal(self, user):
        if user.maxHealth - user.health >=50:
            user.health += 50
        else: user.health = user.maxHealth
        user.mana -= 50

    def update(self):
        self.timeOnScreen += 1
        if self.timeOnScreen > Heal.time:
            self.kill()

class BombTrap(Attack):
    power = 45
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.x, self.y = x, y
        self.image = pygame.transform.scale(pygame.image.load('images/bomb.png'), (30,30)).convert_alpha()
        self.rect = (x-15, y-15, 30,30)

class Rocket(Attack):
    speed = 7
    time = 100
    size = 20
    power = 80
    rockets = []
    def __init__(self, x, y, dir):
        #super(x, y, dir).__init__()
        self.dir = dir
        self.x = x
        self.y = y
        pygame.sprite.Sprite.__init__(self)
        size = Rocket.size
        self.timeOnScreen = 0
        self.damage = 80
        self.image = pygame.transform.scale(pygame.image.load('images/rocket.png').convert_alpha(), (40,15))
        self.rect = pygame.Rect(x,y,10,10)
        Rocket.rockets.append(self)
        
    def update(self, screenWidth, screenHeight):
        if self.dir == 'up':
            self.x += 0
            self.y -= Rocket.speed
            self.image = pygame.transform.scale(pygame.image.load('images/rocketU.png').convert_alpha(), (15,40))
            self.rect.x += 0
            self.rect.y -= Rocket.speed
        elif self.dir == 'right':
            self.x += Rocket.speed
            self.y -= 0
            self.image = pygame.transform.scale(pygame.image.load('images/rocketR.png').convert_alpha(), (40,15))
            self.rect.x += Rocket.speed
            self.rect.y -= 0
        elif self.dir == 'left':
            self.x -= Rocket.speed
            self.y -= 0
            self.image = pygame.transform.scale(pygame.image.load('images/rocket.png').convert_alpha(), (40,15))
            self.rect.x -= Rocket.speed
            self.rect.y -= 0
        if self.dir == 'down':
            self.x += 0
            self.y += Rocket.speed
            self.image = pygame.transform.scale(pygame.image.load('images/rocketD.png').convert_alpha(), (15,40))
            self.rect.x += 0
            self.rect.y += Rocket.speed
        self.timeOnScreen += 1
        if self.timeOnScreen > Rocket.time:
            self.kill()

class Fireball(Attack):
    speed = 5
    time = 100
    size = 10
    power = 20
    fireballs = []
    def __init__(self, x, y, dir):
        #super(x, y, dir).__init__()
        self.dir = dir
        self.x = x
        self.y = y
        pygame.sprite.Sprite.__init__(self)
        size = Fireball.size
        self.timeOnScreen = 0
        self.damage = 20
        self.image = pygame.transform.scale(pygame.image.load('images/fireball.gif').convert_alpha(), (20,20))
        self.rect = pygame.Rect(x,y,10,10)
        Fireball.fireballs.append(self)
        
    def update(self, screenWidth, screenHeight):
        if self.dir == 'up':
            self.x += 0
            self.y -= Fireball.speed
            self.rect.x += 0
            self.rect.y -= Fireball.speed
        elif self.dir == 'right':
            self.x += Fireball.speed
            self.y -= 0
            self.rect.x += Fireball.speed
            self.rect.y -= 0
        elif self.dir == 'left':
            self.x -= Fireball.speed
            self.y -= 0
            self.rect.x -= Fireball.speed
            self.rect.y -= 0
        if self.dir == 'down':
            self.x += 0
            self.y += Fireball.speed
            self.rect.x += 0
            self.rect.y += Fireball.speed
        self.timeOnScreen += 1
        if self.timeOnScreen > Fireball.time:
            self.kill()



class Firewave(Attack):
    speed = 3
    time = 450
    size = 30
    power = 40
    firewaves = []
    def __init__(self, x, y, dir):
        #super(x, y, dir).__init__()
        self.dir = dir
        self.x = x
        self.y = y
        pygame.sprite.Sprite.__init__(self)
        size = Firewave.size
        self.timeOnScreen = 0
        self.damage = 40
        self.size = (30,60)
        self.image = pygame.transform.scale(pygame.image.load('images/firewave.gif').convert_alpha(), self.size)
        self.rect = pygame.Rect(x,y,*self.size)
        Firewave.firewaves.append(self)
        
    def update(self, screenWidth, screenHeight):
        if self.dir == 'up':
            self.x += 0
            self.y -= Firewave.speed
            self.rect.x += 0
            self.rect.y -= Firewave.speed
            self.size = (60,30)
            self.image = pygame.transform.scale(pygame.image.load('images/firewaveUp.gif').convert_alpha(), self.size)
        elif self.dir == 'right':
            self.x += Firewave.speed
            self.y -= 0
            self.rect.x += Firewave.speed
            self.rect.y -= 0
            self.size = (30,60)
            self.image = pygame.transform.scale(pygame.image.load('images/firewaveRight.gif').convert_alpha(), self.size)
        elif self.dir == 'left':
            self.x -= Firewave.speed
            self.y -= 0
            self.rect.x -= Firewave.speed
            self.rect.y -= 0
            self.size = (30,60)
            self.image = pygame.transform.scale(pygame.image.load('images/firewave.gif').convert_alpha(), self.size)
        if self.dir == 'down':
            self.x += 0
            self.y += Firewave.speed
            self.rect.x += 0
            self.rect.y += Firewave.speed
            self.size = (60,30)
            self.image = pygame.transform.scale(pygame.image.load('images/firewaveDown.gif').convert_alpha(), self.size)
        self.timeOnScreen += 1
        if self.timeOnScreen > Firewave.time:
            self.kill()

class Pistol(Attack):
    speed = 8
    time = 100
    size = 10
    power = 10
    bullets = []
    def __init__(self, x, y, dir):
        #super(x, y, dir).__init__()
        self.dir = dir
        self.x = x
        self.y = y
        pygame.sprite.Sprite.__init__(self)
        size = Pistol.size
        self.timeOnScreen = 0
        self.damage = 5
        self.image = pygame.transform.scale(pygame.image.load('images/bullet.png').convert_alpha(), (50,50))
        self.rect = pygame.Rect(x,y,10,10)
        Fireball.fireballs.append(self)
        
    def update(self, screenWidth, screenHeight):
        if self.dir == 'up':
            self.image = pygame.transform.scale(pygame.image.load('images/bulletUp.png').convert_alpha(), (50,50))
            self.x += 0
            self.y -= Fireball.speed
            self.rect.x += 0
            self.rect.y -= Fireball.speed
        elif self.dir == 'right':
            self.x += Fireball.speed
            self.y -= 0
            self.rect.x += Fireball.speed
            self.rect.y -= 0
        elif self.dir == 'left':
            self.x -= Fireball.speed
            self.y -= 0
            self.rect.x -= Fireball.speed
            self.rect.y -= 0
        if self.dir == 'down':
            self.image = pygame.transform.scale(pygame.image.load('images/bulletDown.png').convert_alpha(), (50,50))
            self.x += 0
            self.y += Fireball.speed
            self.rect.x += 0
            self.rect.y += Fireball.speed
        self.timeOnScreen += 1
        if self.timeOnScreen > Fireball.time:
            self.kill()

class NinjaStar(Attack):
    speed = 15
    time = 50
    size = 10
    power = 7
    stars = []
    def __init__(self, x, y, dir):
        #super(x, y, dir).__init__()
        self.dir = dir
        self.x = x
        self.y = y
        pygame.sprite.Sprite.__init__(self)
        size = Pistol.size
        self.timeOnScreen = 0
        self.damage = 5
        self.image = pygame.transform.scale(pygame.image.load('images/star.png').convert_alpha(), (50,50))
        #image from https://openclipart.org/user-cliparts/Inkie30
        self.rect = pygame.Rect(x,y,10,10)
        NinjaStar.stars.append(self)
        
    def update(self, screenWidth, screenHeight):
        if self.dir == 'up':
            self.image = pygame.transform.scale(pygame.image.load('images/star.png').convert_alpha(), (50,50))
            self.x += 0
            self.y -= NinjaStar.speed
            self.rect.x += 0
            self.rect.y -= NinjaStar.speed
        elif self.dir == 'right':
            self.x += NinjaStar.speed
            self.y -= 0
            self.rect.x += NinjaStar.speed
            self.rect.y -= 0
        elif self.dir == 'left':
            self.x -= NinjaStar.speed
            self.y -= 0
            self.rect.x -= NinjaStar.speed
            self.rect.y -= 0
        if self.dir == 'down':
            self.image = pygame.transform.scale(pygame.image.load('images/star.png').convert_alpha(), (50,50))
            self.x += 0
            self.y += NinjaStar.speed
            self.rect.x += 0
            self.rect.y += NinjaStar.speed
        self.timeOnScreen += 1
        if self.timeOnScreen > NinjaStar.time:
            self.kill()
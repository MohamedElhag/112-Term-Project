readme.txt
Mohamed Elhag
melhag
Section M
15-112 Spring 2018


A Timely RPG
    readme

3rd Party Libraries Required:
    pygame


-To run you must first have Pygame installed on your computer along with Python3
-To install these, look up the steps and install it lol


-RUNNING Game.py (A Timely RPG)
open
    all of the files onto your Computer
    make sure the files are saved in the same order as seen in my folder 'TP'



-Playing it
Run the game using your Python IDE of choice and click instructions to learn how to play
Learn how to play from the instructions section:
The Game:
The goal of the game is to defeat the boss at the end of the map in the fastest time possible regardless of the class you choose, so choose which works best with you.
There are items which may seem unreachable, but I suggest testing the functionality of the fences ;).
Revisit some chests to restock before facing off against the final boss.
Monsters get harder as you go.

How to Play:
Use W-A-S-D keys to move in four directions
Hold SPACE to run
Press G for basic attack
Press I for inventory, which also maps keys to more attacks
Press M for mute and unmute music 
UP and DOWN arrows control the volume


-EXITING
Any time the video stream is active, pressing the x button in the top left corner will close the program
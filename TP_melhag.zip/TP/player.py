import pygame

class Player(pygame.sprite.Sprite):
    images = []
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.x = x
        self.y = y
        self.dx = 10
        self.dy = 10
        self.size = (50,50)
        self.dir = 'left'
        self.image = pygame.transform.scale(pygame.image.load('images/temp2.png'), self.size)
        self.rect = pygame.Rect(x,y,30,30)
        rows, cols = 4, 4
        width, height = image.get_size()
        cellWidth, cellHeight = width / cols, height / rows
        for i in range(cols):
            for j in range(rows):
                try:
                    subImage = image.subsurface(
                        (i * cellHeight, j * cellWidth, cellWidth, cellHeight))
                    Player.images.append(pygame.transform.scale(subImage, self.size))
                except: continue
        
    def update(self, keysDown, screenWidth, screenHeight, dt):
        self.timer+=1
        if keysDown(pygame.K_a):
            if self.rect.x > 0:
                if self.timer%5==0:
                    self.step+=1
                self.image = pygame.transform.scale(pygame.image.load(self.leftStep[self.step%4]), self.size)
                self.dir = 'left'
                #self.x -= self.dx
                self.rect.x -= self.dx

        elif keysDown(pygame.K_d):
            if self.rect.x < screenWidth-50:
                if self.timer%5==0:
                    self.step+=1
                self.dir = 'right'
                self.image = pygame.transform.scale(pygame.image.load(self.rightStep[self.step%4]), self.size)
                #self.x += self.dx
                self.rect.x += self.dx

        elif keysDown(pygame.K_w):
            if self.rect.y > 0:
                if self.timer%5==0:
                    self.step+=1
                self.image = pygame.transform.scale(pygame.image.load(self.upStep[self.step%4]), self.size)
                self.dir = 'up'
                #self.y -= self.dy
                self.rect.y -= self.dy
            
        elif keysDown(pygame.K_s):
            if self.rect.y < screenHeight-50:
                if self.timer%5==0:
                    self.step+=1
                self.image = pygame.transform.scale(pygame.image.load(self.downStep[self.step%4]), self.size)
                self.dir = 'down'
                #self.y += self.dy
                self.rect.y += self.dy


class Mage(Player):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.rect = pygame.Rect(x,y,50,50)
        self.x = self.rect.x
        self.y = self.rect.y
        self.dx = 5
        self.dy = 5
        self.size = (50,50)
        self.dir = 'left'
        self.health = 100
        self.maxHealth = 100
        self.healing = False
        self.firewave = False
        self.mana = 100
        self.maxMana = 100
        self.timer = 0
        self.step = 0
        self.potion = 0
        self.image = pygame.transform.scale(pygame.image.load('images/mage3.png'), self.size)
        self.leftStep = ['images/mage3.png','images/mageLStep1.png','images/mage3.png','images/mageLStep2.png']
        self.downStep = ['images/mage1.png','images/mageDStep1.png','images/mage1.png','images/mageDStep2.png']
        self.rightStep = ['images/mage4.png','images/mageRStep1.png','images/mage4.png','images/mageRStep2.png']
        self.upStep = ['images/mage2.png','images/mageUStep1.png','images/mage2.png','images/mageUStep2.png']

class Gunner(Player):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.rect = pygame.Rect(x,y,50,50)
        self.x = self.rect.x
        self.y = self.rect.y
        self.dx = 2
        self.dy = 2
        self.size = (50,50)
        self.dir = 'left'
        self.health = 120
        self.maxHealth = 120
        self.mana = 15
        self.maxMana = 30
        self.ammo = 15
        self.reload = 2
        self.step = 0
        self.timer = 0
        self.potion = 0
        self.rockets = 0
        self.leftStep = ['images/gunner3.png','images/gunnerLStep1.png','images/gunner3.png','images/gunnerLStep2.png']
        self.downStep = ['images/gunner1.png','images/gunnerDStep1.png','images/gunner1.png','images/gunnerDStep2.png']
        self.rightStep = ['images/gunner4.png','images/gunnerRStep1.png','images/gunner4.png','images/gunnerRStep2.png']
        self.upStep = ['images/gunner2.png','images/gunnerUStep1.png','images/gunner2.png','images/gunnerUStep2.png']
        self.image = pygame.transform.scale(pygame.image.load('images/gunner3.png'), self.size)

class Ninja(Player):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.rect = pygame.Rect(x,y,50,50)
        self.x = self.rect.x
        self.y = self.rect.y
        self.dx = 3
        self.dy = 3
        self.size = (50,50)
        self.dir = 'left'
        self.health = 125
        self.maxHealth = 100
        self.mana = 25
        self.maxMana = 40
        self.stars = 0
        self.bombs = 10
        self.timer = 0
        self.step = 0
        self.potion = 0
        self.leftStep = ['images/ninja3.png','images/ninjaLStep1.png','images/ninja3.png','images/ninjaLStep2.png']
        self.downStep = ['images/ninja1.png','images/ninjaDStep1.png','images/ninja1.png','images/ninjaDStep2.png']
        self.rightStep = ['images/ninja4.png','images/ninjaRStep1.png','images/ninja4.png','images/ninjaRStep2.png']
        self.upStep = ['images/ninja2.png','images/ninjaUStep1.png','images/ninja2.png','images/ninjaUStep2.png']
        self.image = pygame.transform.scale(pygame.image.load('images/ninja3.png'), self.size)
        


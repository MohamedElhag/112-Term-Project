'''
pygamegame.py
created by Lukas Peraza
 for 15-112 F15 Pygame Optional Lecture, 11/11/15

use this code in your term project if you want
- CITE IT
- you can modify it to your liking
  - BUT STILL CITE IT

- you should remove the print calls from any function you aren't using
- you might want to move the pygame.display.flip() to your redrawAll function,
    in case you don't need to update the entire display every frame (then you
    should use pygame.display.update(Rect) instead)
'''
import pygame
import random
from player import Player, Mage, Gunner, Ninja
from monster import Monster, Boss
from maps import Grass
from attacks import Fireball, Heal, Pistol, BombTrap, NinjaStar, Firewave, Rocket
from items import Item
from Explosion import Explosion
from BasicFileIO import readFile, writeFile
            
class Bg(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('images/map.png')
        rows, cols = 2, 2
        width, height = self.image.get_size()
        cellWidth, cellHeight = width / cols, height / rows
        Player.images = []
        topLeft = self.image.subsurface(0,0,width/2, height/2)
        topRight = self.image.subsurface(width/2, 0, width/2, height/2)
        bottomLeft = self.image.subsurface(0, height/2, width/2, height/2)
        bottomRight = self.image.subsurface(width/2, height/2, width/2, height/2)
        self.rect = self.image.get_rect()

class PygameGame(object):

    def init(self):
        Explosion.init()
        self.start = True
        self.instructions = False
        self.playerSelect = False
        self.level = 0
        self.bag = False
        self.p1 = None
        self.player = pygame.sprite.GroupSingle()
        self.attacks = pygame.sprite.Group()
        self.monsters = pygame.sprite.Group()
        self.fireballs = pygame.sprite.Group()
        self.stars = pygame.sprite.Group()
        self.pistolBullets = pygame.sprite.Group()
        self.rockets = pygame.sprite.Group()
        self.water = pygame.transform.scale(pygame.image.load('images/water.png'), (int(self.width*.4), self.height//3*2))
        self.waterRect1 = (0,self.height//4-50, int(self.width*.4), self.height//2)
        self.water2 = pygame.transform.scale(pygame.image.load('images/water.png'), (int(self.width*.4), self.height//3*2))
        self.waterRect2 = (int(self.width*.7),self.height//4, int(self.width*.4), self.height//2)
        self.timer = 0
        self.explosions = pygame.sprite.Group()
        self.traps = pygame.sprite.Group()
        self.lose = False
        self.prevLevel = 0
        self.level = 0
        self.levelComplete = False
        self.backButton = (220,220,0)
        self.grassRects = []
        self.grass = pygame.sprite.Group()
        self.muted = False
        self.volume = 50
        self.startBG = pygame.transform.scale(pygame.image.load('images/bgfornow.png'),(self.width, self.height))
        self.bg = pygame.transform.scale(pygame.image.load('images/bg.png'),(self.width, self.height))
        self.startBGrect = self.startBG.get_rect()
        self.smallText = pygame.font.Font('freesansbold.ttf', 15)
        self.mediumText = pygame.font.Font('freesansbold.ttf', 25)
        self.largeText = pygame.font.Font('freesansbold.ttf', 50)
        self.select1 = (255,255,0)
        self.select2 = (255,255,0)
        self.select3 = (255,255,0)
        self.selected = (0,220,220)
        self.heal = None
        self.testGrass = pygame.sprite.Group()
        self.gameWon = False
        self.finishTime = 0
        #self.t1 = Grass(self.width//2, self.height//2, )
        #self.testGrass.add(self.t1)
        self.Heal = pygame.sprite.Group()
        self.item1 = Item(50,50)
        self.item2 = Item(50, self.height//2)
        self.item3 = Item(self.width-50,50)
        self.item5 = Item(self.width//2-20, self.height//2-15)
        self.items = pygame.sprite.Group()
        self.gameOverBG = pygame.transform.scale(pygame.image.load('images/gameOver.jpg'), (self.width, self.height))
        self.gameOverRect = self.gameOverBG.get_rect()
        self.l1Monsters = pygame.sprite.Group()
        self.l2Monsters = pygame.sprite.Group()
        self.l3Monsters = pygame.sprite.Group()
        self.l4Monsters = pygame.sprite.Group()
        self.bossMonsters = pygame.sprite.Group()
        self.boss = Boss(self.width//2-60, self.height//10)
        for i in range(3):
            x = 0
            y = random.randrange(150, 220)
            self.l1Monsters.add(Monster(x,y,5,1))
        for i in range(3):
            x = random.randrange(150, 220)
            y = 0
            self.l2Monsters.add(Monster(x,y,7,1))
        for i in range(5):
            x = random.randrange(self.width//3, self.width//3*2-20)
            y = 0
            self.l3Monsters.add(Monster(x,y,7,1.5))
        for i in range(5):
            x = random.randrange(self.width//3, self.width//3*2-20)
            y = 0
            self.l4Monsters.add(Monster(x,y,7,1.5))
        self.bossMonsters.add(self.boss)
        self.bossMonsters.add(Monster(self.width//4, self.height//3, 7,1.5))
        self.bossMonsters.add(Monster(self.width*.75, self.height//3, 7,1.5))
        self.levelOneBlocks = [ ['grass','grass','grass','grass','grass','grass','grass','grass','tree','grass','grass','grass'],
                                ['grass','grass','grass','tree','grass','grass','grass','grass','grass','grass','grass','grass'],
                                ['fence','fence','fake','fence','fence','fence','fence','fence','fence','fence','fence','fence'],
                                ['','','','','','','','','','','',''],
                                ['','','','','','','','','','','',''],
                                ['','','','','','','','','','','',''],
                                ['fence','fence','fence','fence','fence','fence','fence','fence','fence','fence','fence','fence'],
                                ['grass','grass','grass','grass','grass','grass','grass','grass','grass','grass','grass','grass'],
                                ]
        self.levelTwoBlocks = [ ['grass','grass','fenceUp','','','','fenceUp','grass','grass','grass','grass','grass'],
                                ['tree','grass','fenceUp','','','','fenceUp','grass','grass','tree','grass','grass'],
                                ['grass','grass','fenceUp','','','','fence','fence','fence','fence','fence','fence'],
                                ['grass','grass','fenceUp','','','','','','','','',''],
                                ['grass','grass','fenceUp','','','','','','','','',''],
                                ['grass','grass','fenceUp','','','','','','','','',''],
                                ['grass','grass','fence','fake','fence','fence','fence','fence','fence','fence','fence','fence'],
                                ['grass','grass','grass','grass','grass','grass','grass','grass','grass','grass','grass','grass'],
                                ]
        self.levelThreeBlocks = [ ['grass','grass','grass','grass','fenceUp','','','','fenceUp','tree','grass','grass'],
                                ['grass','grass','grass','grass','fenceUp','','','','fenceUp','grass','grass','grass'],
                                ['grass','grass','grass','fenceUp','','','','','fence','fenceUp','grass','grass'],
                                ['grass','tree','grass','fenceUp','','','','','','fenceUp','grass','grass'],
                                ['grass','grass','grass','fenceUp','','','','','','fake','grass','tree'],
                                ['grass','grass','grass','fenceUp','','','','','','fenceUp','grass','grass'],
                                ['tree','grass','grass','fence','fenceUp','','','','fenceUp','grass','grass','grass'],
                                ['grass','grass','grass','grass','fenceUp','','','','fenceUp','grass','grass','grass'],
                                ]
        self.levelFourBlocks = [ ['','','','','','','','','','','',''],
                                ['','','','','','','','','','','',''],
                                ['','','','','','','','','','','',''],
                                ['','','','','','','','','','','',''],
                                ['','','','','','','','','','','',''],
                                ['','','','','','','','','','','',''],
                                ['','','','','','','','','','','',''],
                                ['','','','','','','','','','','',''],
                                ]
        self.bossLevelBlocks = [ ['fence','fence','fence','fence','','','','','fence','fence','fence','fence'],
                                ['fenceUp','','','','','','','','','','','fenceUp'],
                                ['fenceUp','','','','','','','','','','','fenceUp'],
                                ['fenceUp','','','','','','','','','','','fenceUp'],
                                ['fenceUp','','','','','','','','','','','fenceUp'],
                                ['fenceUp','','','','','','','','','','','fenceUp'],
                                ['fenceUp','','','','','','','','','','','fenceUp'],
                                ['fence','fence','fence','fence','','','','','fence','fence','fence','fence'],
                                ]
        self.top = (self.width//2, 51)
        self.left = (7, self.height//2)
        self.right = (self.width-51, self.height//2)
        self.bottom = (self.width//2,self.height-55)

    def levelOneMap(self, screen):
        self.grass = pygame.sprite.Group()
        numCols = self.width//50
        numRows = self.height//50
        if self.level==1:
            blocks = self.levelOneBlocks
        elif self.level==2:
            self.grass = pygame.sprite.Group()
            blocks = self.levelTwoBlocks
        elif self.level==3:
            self.grass = pygame.sprite.Group()
            blocks = self.levelThreeBlocks
        elif self.level==4:
            bridge = pygame.transform.scale(pygame.image.load('images/bridge.png'),(int(self.width*.3), self.height//2+75))
            bridgeRect = (int(self.width*.4),self.height//4-30, int(self.width*.3),self.height//2+75)
            screen.blit(bridge, bridgeRect)
            self.grass.add(Grass(0,self.height//4-30, self.water, (int(self.width*.4), self.height//2)))
            self.grass.add(Grass(int(self.width*.7),self.height//4-30, self.water,(int(self.width*.4), self.height//2)))
            blocks = self.levelFourBlocks
        elif self.level==5:
            blocks = self.bossLevelBlocks
        grassImg = pygame.transform.scale(pygame.image.load('images/grass.png'), (50,50))
        #image from https://rayquaza-dot.deviantart.com/art/Pokemon-Platinum-Grass-Autotile-293299604
        for row in range(numRows):
            for col in range(numCols):
                try:
                    if blocks[row][col]=='grass':
                        screen.blit(grassImg, (col*50, row*50, 50,50))
                    elif blocks[row][col]=='tree':
                        image = pygame.transform.scale(pygame.image.load('images/tree.png'), (100,100))
                        #image from https://midnitez-remix.deviantart.com/art/Pokemon-ORAS-BuzzNav-People-494296975
                        screen.blit(image, ((col-.5)*50,(row-.5)*50,100,100))
                    elif blocks[row][col]=='fence':
                        image = pygame.transform.scale(pygame.image.load('images/fence.png'), (50,50))
                        #image from https://officialpetsociety.wordpress.com/2011/05/
                        self.grass.add(Grass(col*50, row*50, image,(50,50)))
                        if blocks[row+1][col]=='' and self.level!=5:
                            screen.blit(grassImg, (col*50, row*50, 50,50))
                    elif blocks[row][col]=='fenceUp':
                        if blocks[row-1][col+1]=='fenceUp':
                            image = pygame.transform.scale(pygame.image.load('images/fence.png'), (50,50))
                            #image from https://officialpetsociety.wordpress.com/2011/05/
                            self.grass.add(Grass(col*50, row*50, image, (50,50)))
                            screen.blit(grassImg, (col*50, row*50,50,50))
                        image = pygame.transform.scale(pygame.image.load('images/fenceUp.png'), (50,100))
                        #image from http://capx.wikia.com/wiki/File:Fence.png#
                        self.grass.add(Grass(col*50-20, row*50, image,(50,50)))
                        if blocks[row][col+1]=='grass':
                            screen.blit(grassImg, (col*50, row*50, 50,50))
                        if blocks[row][col+1]=='tree':
                            screen.blit(grassImg, (col*50, row*50, 50,50))
                    elif blocks[row][col]=='fake':
                        if blocks[row+1][col]=='':
                            screen.blit(grassImg, (col*50, row*50, 50,50))
                        image = pygame.transform.scale(pygame.image.load('images/fence.png'), (50,50))
                        #image from https://officialpetsociety.wordpress.com/2011/05/
                        screen.blit(image,(col*50,row*50,50,50))
                except:
                    continue

                '''if (row,col) in blocks['horizontal']:
                    image = pygame.transform.scale(pygame.image.load('images/fence.png'), (50,50))
                    self.grass.add(Grass(col*50, row*50, image))
                    
                    if self.height - row*50 > row*50:
                        screen.blit(grassImg, (col*50, (row)*50, 50,50))
                    else:
                        screen.blit(grassImg, (col*50, (row+1)*50, 50,50))
                elif (row,col) in blocks['vertical']:
                    image = pygame.transform.scale(pygame.image.load('images/fenceUp.png'), (50,100))
                    self.grass.add(Grass(col*50-20, row*50, image))
                    if self.width - col*50 > col*50:
                        
                        screen.blit(grassImg, ((col-1)*50, row*50, 50,50))
                    else:
                        screen.blit(grassImg, (col*50, row*50, 50,50))
                elif (row,col) in blocks['grass']:
                    screen.blit(grassImg, (col*50, row*50, 50,50))'''


        self.grass.draw(screen)

    """def transitions(self):
        if len(self.monsters)==0 and self.p1.rect.x<=1:
            self.level += 1
            if level=1:
                start = self.left
            elif level
            self.p1.rect.x, self.p1.rect.y = start"""
    
    def healthBar(self,screen):
        if self.p1.health > 70:
            color = (0,255,0)
        elif self.p1.health > 30 and self.p1.health<=70:
            color = (255,255,0)
        else: color = (255,0,0)
        rect = (5,5,15,self.p1.health*1.5)
        pygame.draw.rect(screen, color, rect)

    def inventory(self, screen):
        if self.bag == True:
            cellSize = 50
            numCols = 5
            y0 = self.height-cellSize-15
            keys = ['G','H','J','K','L']
            if type(self.p1)==Mage:
                fireImg = pygame.transform.scale(pygame.image.load('images/fireball.gif'), (cellSize-5, cellSize-5))
                #image from https://giphy.com/stickers/sprite-4KnYdzoz83wkw
                screen.blit(fireImg, (15, y0, cellSize-5, cellSize-5))
                if self.p1.healing == True:
                    healImg = pygame.transform.scale(pygame.image.load('images/heal.gif'), (cellSize-5, cellSize-5))
                    #image from http://pikky126.tumblr.com/post/146638341683/i-made-a-sprite-and-animation-for-the-8-bit
                    screen.blit(healImg, (cellSize+15, y0, cellSize-5, cellSize-5))
                if self.p1.firewave == True:
                    waveImg = pygame.transform.scale(pygame.image.load('images/firewave.gif'), (cellSize-5, cellSize-15))
                    #image from http://pikky126.tumblr.com/post/146638341683/i-made-a-sprite-and-animation-for-the-8-bit
                    screen.blit(waveImg, ((cellSize*2)+15, y0, cellSize-5, cellSize-5))
                if self.p1.potion>0:
                    healImg = pygame.transform.scale(pygame.image.load('images/heal.gif'), (cellSize-5, cellSize-5))
                    #image from http://pikky126.tumblr.com/post/146638341683/i-made-a-sprite-and-animation-for-the-8-bit
                    screen.blit(healImg, ((cellSize)+15, y0, cellSize-5, cellSize-5))
            if type(self.p1)==Ninja:
                bombImg = pygame.transform.scale(pygame.image.load('images/bomb.png'), (cellSize-5, cellSize-5)).convert_alpha()
                screen.blit(bombImg, (15, y0, cellSize-5, cellSize-5))
                if self.p1.stars>0:
                    star = pygame.transform.scale(pygame.image.load('images/star.png'), (cellSize-5, cellSize-5)).convert_alpha()
                    screen.blit(star, (cellSize+15, y0, cellSize-5, cellSize-5))
                if self.p1.potion>0:
                    healImg = pygame.transform.scale(pygame.image.load('images/heal.gif'), (cellSize-5, cellSize-5))
                    #image from http://pikky126.tumblr.com/post/146638341683/i-made-a-sprite-and-animation-for-the-8-bit
                    screen.blit(healImg, ((cellSize*2)+15, y0, cellSize-5, cellSize-5))

            if type(self.p1)==Gunner:
                pistolImg = pygame.transform.scale(pygame.image.load('images/pistol.png'), (cellSize-5, cellSize-5))
                #image from https://ksalmanoglu.deviantart.com/art/8-bit-revolver-design-514896192
                screen.blit(pistolImg, (15, y0, cellSize-5, cellSize-5))
                if self.p1.potion>0:
                    healImg = pygame.transform.scale(pygame.image.load('images/heal.gif'), (cellSize-5, cellSize-5))
                    #image from http://pikky126.tumblr.com/post/146638341683/i-made-a-sprite-and-animation-for-the-8-bit
                    screen.blit(healImg, ((cellSize)+15, y0, cellSize-5, cellSize-5))
                if self.p1.rockets>0:
                    rocketImg = pygame.transform.scale(pygame.image.load('images/rocket.png'), (cellSize-5, cellSize-5))
                    #image from http://pikky126.tumblr.com/post/146638341683/i-made-a-sprite-and-animation-for-the-8-bit
                    screen.blit(rocketImg, ((cellSize*2)+15, y0, cellSize-5, cellSize-5))

            for col in range(numCols):
                x0 = col*cellSize + 15
                pygame.draw.rect(screen, (139,69,19), (x0,y0,cellSize, cellSize), 2)
                inventoryKeys, keyRect = self.textObjects("%s" %(keys[col]), self.smallText, (255,255,255))
                keyRect.center = (x0+15, y0+40)
                screen.blit(inventoryKeys, keyRect)
    
    def textObjects(self, text, font, color):
        textSurf = font.render(text, True, color)
        return textSurf, textSurf.get_rect()

    def manaBar(self, screen):
        color = (0,0,255)
        rect = (20,5,10,self.p1.mana*1)
        pygame.draw.rect(screen, color, rect)
        
    def statusBar(self,screen):
        if type(self.p1) == Gunner:
            ammoButton, ammoRect = self.textObjects("ammo: %d" %(self.p1.ammo), self.smallText, (0,0,0))
            ammoRect.center = (35, 175)
            screen.blit(ammoButton, ammoRect)
            magsButton, magsRect = self.textObjects("mags: %d" %(self.p1.reload), self.smallText, (0,0,0))
            magsRect.center = (30, 200)
            screen.blit(magsButton, magsRect)
        self.healthBar(screen)
        self.manaBar(screen)
        time, timeRect = self.textObjects("Time: %d" %self.finishTime, self.smallText, (255,255,255))
        timeRect.center = (self.width-35, 25)
        screen.blit(time, timeRect)
        info, infoRect = self.textObjects("press 'I' to check inventory", self.smallText, (255,255,255))
        infoRect.center = (self.width-100, 10)
        screen.blit(info, infoRect)
        if self.level==5:
            if self.boss.health > 700:
                color = (0,255,0)
            elif self.boss.health > 300 and self.boss.health<=700:
                color = (255,255,0)
            else: color = (255,0,0)
            rect = (5,5,15,self.p1.health*1.5)
            pygame.draw.rect(screen, color, rect)

        
    def mousePressed(self, x, y):
        if self.start==True:
            if x>=self.width//1.75 and x<=((self.width//1.75)+100) and y>=(self.height//1.2) and y<=((self.height//1.2)+30):
                self.start = False
                self.instructions = True
            if x>=self.width//3.75 and x<=((self.width//3.75)+100) and y>=(self.height//1.2) and y<=((self.height//1.2)+30):
                self.playerSelect = True
                self.start = False
        if self.instructions==True:
            if x>=20 and x<=120 and y>=20 and y<=50:
                self.instructions = False
                self.start = True
        if self.playerSelect==True:
            if x>=20 and x<=120 and y>=20 and y<=50:
                self.playerSelect = False
                self.start = True
                self.select1=self.select2=self.select3=(255,255,0)
            #Ninja selected
            if (x in range((self.width//4)-40, (self.width//4)+40)) and (y in range((self.height//2)-50, (self.height//2)+65)):
                self.playerSelect = False
                self.level = 1
                self.p1 = Ninja(self.width-50, self.height//2)
                self.player.add(self.p1)
            #mage selected
            if (x in range((self.width//2)-40, (self.width//2)+40)) and (y in range((self.height//2)-50, (self.height//2)+65)):
                self.playerSelect = False
                self.level = 1
                self.p1 = Mage(self.width-50, self.height//2)
                self.player.add(self.p1)
            #Gunner selected
            if (x in range((self.width*3//4)-40, (self.width*3//4)+40)) and (y in range((self.height//2)-50, (self.height//2)+65)):
                self.playerSelect = False
                self.level = 1
                self.p1 = Gunner(self.width-50, self.height//2)
                self.player.add(self.p1)

    def mouseReleased(self, x, y):
        pass

    def mouseMotion(self, x, y):
        if self.playerSelect==True:
            if (x in range(self.width//4-50,self.width//4+50)) and (y in range(self.height//2-75, self.height//2+75)):
                self.select1 = self.selected
            elif (x in range(self.width//2-50,self.width//2+50)) and (y in range(self.height//2-55, self.height//2+95)):
                self.select2 = self.selected
            elif (x in range(self.width*3//4-50,self.width*3//4+50)) and (y in range(self.height//2-75, self.height//2+75)):
                self.select3 = self.selected
            else:
                self.select1=self.select2=self.select3=(255,255,0)
        if (x in range(20,121)) and (y in range(20,51)):
            self.backButton = self.selected
        else:
            self.backButton = (220,220,0)

    def mouseDrag(self, x, y):
        pass

    def keyPressed(self, keyCode, modifier):
        '''if keyCode == pygame.K_UP:
            self.level+=1
        elif keyCode == pygame.K_DOWN and self.level!=1:
            self.level -= 1'''
        #in gameplay
        if self.level != 0:
            #Space bar
            if keyCode == pygame.K_SPACE:
                self.p1.dx, self.p1.dy = 7, 7
            #G
            if keyCode == pygame.K_g:
                #FIREBALL ATTACK
                """if self.p1.dir == 'left':
                    self.p1.image = pygame.transform.scale(Player.images[19], self.p1.size)
                else:
                    self.p1.image = pygame.transform.flip(pygame.transform.scale(Player.images[19], self.p1.size), True, False)"""
                if type(self.p1)==Mage and self.p1.mana >= 10:
                    self.p1.mana -= 10
                    self.fireballs.add(Fireball(self.p1.rect.x+15, self.p1.rect.y+15, self.p1.dir))
                elif type(self.p1)==Gunner and self.p1.ammo > 0:
                    self.p1.ammo -= 1
                    self.pistolBullets.add(Pistol(self.p1.rect.x, self.p1.rect.y, self.p1.dir))
                elif type(self.p1)==Ninja and self.p1.bombs>0:
                    self.p1.bombs -= 1
                    self.traps.add(BombTrap(self.p1.rect.x, self.p1.rect.y))
            #I
            if keyCode == pygame.K_i:
                self.bag = not self.bag
            #H
            if keyCode == pygame.K_h:
                #Healing
                if type(self.p1)==Mage and self.p1.healing==True and self.p1.mana>=50:
                    self.heal = Heal(self.p1)
                    self.Heal.add(self.heal)
                    self.heal.heal(self.p1)
                if type(self.p1)==Mage and self.healing==False and self.p1.potion>0:
                    self.p1.mana += 50
                    self.p1.potion-=1
                    self.heal = Heal(self.p1)
                    self.Heal.add(self.heal)
                    self.heal.heal(self.p1)
                if type(self.p1)==Ninja and self.p1.stars>0:
                    self.p1.stars-=1
                    self.stars.add(NinjaStar(self.p1.rect.x+15, self.p1.rect.y+15, self.p1.dir))
                if type(self.p1)==Gunner and self.p1.potion>0:
                    self.p1.mana += 50
                    self.p1.potion-=1
                    self.heal = Heal(self.p1)
                    self.Heal.add(self.heal)
                    self.heal.heal(self.p1)
            #J
            if keyCode == pygame.K_j:
                if type(self.p1)==Mage and self.p1.firewave==True and self.p1.mana>=25:
                    self.p1.mana -= 25
                    self.fireballs.add(Firewave(self.p1.rect.x+15, self.p1.rect.y+15, self.p1.dir))
                elif type(self.p1)==Ninja and self.p1.potion>0:
                    self.p1.mana += 50
                    self.p1.potion-=1
                    self.heal = Heal(self.p1)
                    self.Heal.add(self.heal)
                    self.heal.heal(self.p1)
                elif type(self.p1)==Gunner and self.p1.rockets>0:
                    self.p1.rockets-=1
                    self.rockets.add(Rocket(self.p1.rect.x+15, self.p1.rect.y+15, self.p1.dir))
            #R
            if keyCode == pygame.K_r:
                if type(self.p1) == Gunner and self.p1.reload>0 and self.p1.ammo<60:
                    self.p1.reload -= 1
                    self.p1.ammo = 15

        #out of gameplay
        if (self.lose == True or self.gameWon) and keyCode == pygame.K_r:
                self.init()
        if keyCode == pygame.K_m:
            if self.muted == False:
                pygame.mixer.music.set_volume(0)
                self.muted = True
            else:
                pygame.mixer.music.set_volume(self.volume)
                self.muted = False
        if keyCode == pygame.K_UP:
            if self.volume<200:
                pygame.mixer.music.set_volume(self.volume+10)
                self.volume+=1
        if keyCode == pygame.K_DOWN:
            if self.volume>=0:
                pygame.mixer.music.set_volume(self.volume-10)
                self.volume-=1

        """if keyCode == pygame.K_w:
            for grass in pygame.sprite.groupcollide(
                self.grass, self.player, False, False,
                pygame.sprite.collide_circle):
                self.p1.y += self.p1.dy
                self.p1.rect.y += self.p1.dy"""

    def keyReleased(self, keyCode, modifier):
        if self.level!=0:
            if keyCode == pygame.K_SPACE:
                self.p1.dx, self.p1.dy = 5, 5

    def obstacleCollisions(self, player, obstacle):
        if not pygame.sprite.collide_rect(player, obstacle):return
        overlap = player.rect.clip(obstacle.rect)
        if overlap.width > overlap.height:
            if player.rect.y < obstacle.rect.y:#from the top
                player.rect.bottom = obstacle.rect.top
            else:#from the bottom
                player.rect.top = obstacle.rect.bottom
        if overlap.height > overlap.width:#from the left
            if player.rect.x < obstacle.rect.x:
                player.rect.right = obstacle.rect.left
            else:#from the right
                player.rect.left = obstacle.rect.right

    def timerFired(self, dt):
        #fowards
        #1-->2
        if self.level==1 and len(self.l1Monsters)==0 and self.p1.rect.x<=1:
            self.p1.rect.x, self.p1.rect.y = self.right[0]-1, self.right[1]
            self.level = 2
            self.traps = pygame.sprite.Group()
        #2-->3
        if self.level==2 and len(self.l2Monsters)==0 and self.p1.rect.y<=1:
            self.p1.rect.x, self.p1.rect.y = self.bottom
            self.level=3
            self.traps = pygame.sprite.Group()

        #3-->4
        if self.level==3 and len(self.l3Monsters)==0 and self.p1.rect.y<=1:
            self.p1.rect.x, self.p1.rect.y = self.bottom
            self.level=4
            self.traps = pygame.sprite.Group()
        #4-->5
        if self.level==4 and len(self.l4Monsters)==0 and self.p1.rect.y<=1:
            self.p1.rect.x, self.p1.rect.y = self.bottom
            self.level=5
            self.traps = pygame.sprite.Group()
        #win
        if self.level==5 and len(self.bossMonsters)==0 and self.p1.rect.y<=1:
            self.gameWon = True
            self.traps = pygame.sprite.Group()

        #backwards
        #2-->1
        if self.level==2 and self.p1.rect.x>=self.width-50 and len(self.l2Monsters)==0:
            self.level = 1
            self.p1.rect.x, self.p1.rect.y = self.left
            self.traps = pygame.sprite.Group()
        #3-->2
        if self.level==3 and self.p1.rect.y>=self.height-49 and len(self.l3Monsters)==0:
            self.level=2
            self.p1.rect.x, self.p1.rect.y = self.top[0]-100, self.top[1]
            self.traps = pygame.sprite.Group()
        #4-->3
        if self.level==4 and self.p1.rect.y>=self.height-49 and len(self.l4Monsters)==0:
            self.level=3
            self.p1.rect.x, self.p1.rect.y = self.top
            self.traps = pygame.sprite.Group()
        #5-->4
        if self.level==5 and self.p1.rect.y>=self.height-49 and len(self.bossMonsters)==0:
            self.level=4
            self.p1.rect.x, self.p1.rect.y = self.top
            self.traps = pygame.sprite.Group()

        if self.level!=0:
            self.timer +=1
            if self.gameWon==False and self.lose == False:
                if self.timer%60==0:
                    self.finishTime+=1
            if self.p1.health <= 0:
                self.level=0
                self.lose = True
            self.explosions.update(dt)
            self.player.update(self.isKeyPressed, self.width, self.height,dt)
            if type(self.p1)==Mage and self.p1.healing == True and self.heal!=None:
                self.heal.update()
        # if self.timer%5==0 and self.p1.health>0 and self.level!=0:
        #     self.p1.health -= 1
            if self.timer%50 == 0 and self.p1.mana<=self.p1.maxMana:
                self.p1.mana += 10
            for grass in pygame.sprite.groupcollide(
                self.grass, self.player, False, False,
                pygame.sprite.collide_rect):
                self.obstacleCollisions(self.p1, grass)
            
            #self.obstacleCollisions(self.t1, self.p1)
            if self.level==0:
                group = pygame.sprite.Group()
            if self.level==1:
                self.items = pygame.sprite.Group()
                group = self.l1Monsters
                self.items.add(self.item1)
            elif self.level==2:
                self.items = pygame.sprite.Group()
                group = self.l2Monsters
                self.items.add(self.item2)
            elif self.level==3:
                self.items = pygame.sprite.Group()
                group = self.l3Monsters
                self.items.add(self.item3)
            elif self.level==4:
                self.items = pygame.sprite.Group()
                group = self.l4Monsters
            elif self.level==5:
                self.items = pygame.sprite.Group()
                group = self.bossMonsters
                self.items.add(self.item5)
            for grass in pygame.sprite.groupcollide(
                self.grass, group, False, False,
                pygame.sprite.collide_rect):
                for monster in pygame.sprite.groupcollide(
                    group, self.grass, False, False,
                    pygame.sprite.collide_rect):
                    self.obstacleCollisions(monster, grass)
            for monster in group:
                chance = random.choice([0,1,0,0])
                if chance == 1:
                    if self.p1.rect.x > monster.rect.x:
                        monster.update((monster.dx),0, dt)
                    if self.p1.rect.x < monster.rect.x:
                        monster.update(-(monster.dx),0, dt)
                    if random.choice([0,0,0,1]) == 1:
                        if self.p1.rect.y > monster.rect.y:
                            monster.update(0,(monster.dy), dt)
                        if self.p1.rect.y < monster.rect.y:
                            monster.update(0,-(monster.dy), dt)
            for monster in pygame.sprite.groupcollide(
                group, self.player, False, False,
                pygame.sprite.collide_rect):
                if self.p1.health>0:
                    chance = random.randint(0,1)
                    if self.level==5:
                        if self.boss.timer%30==0:
                            self.p1.health -= monster.power
                    elif chance == 1:
                        self.p1.health -= monster.power
            self.fireballs.update(self.width, self.height)
            self.stars.update(self.width, self.height)
            self.pistolBullets.update(self.width, self.height)
            self.rockets.update(self.width,self.height)
            for monster in pygame.sprite.groupcollide(
                group, self.fireballs, False, True,
                pygame.sprite.collide_rect):
                monster.health -= Fireball.power
                if monster.health<= 0:
                    monster.kill()
            for monster in pygame.sprite.groupcollide(
                group, self.stars, False, True,
                pygame.sprite.collide_rect):
                monster.health -= NinjaStar.power
                if monster.health<= 0:
                    monster.kill()
            for monster in pygame.sprite.groupcollide(
                group, self.pistolBullets, False, True,
                pygame.sprite.collide_rect):
                monster.health -= Pistol.power
                if monster.health<= 0:
                    monster.kill()
            for monster in pygame.sprite.groupcollide(
                group, self.rockets, False, True,
                pygame.sprite.collide_rect):
                self.explosions.add(Explosion(monster.rect.x+25, monster.rect.y+25))
                monster.health -= Rocket.power
                if monster.health<= 0:
                    monster.kill()
            for monster in pygame.sprite.groupcollide(
                group, self.traps, False, True,
                pygame.sprite.collide_rect):
                self.explosions.add(Explosion(monster.rect.x+25, monster.rect.y+25))
                monster.health -= BombTrap.power
                if monster.health<= 0:
                    monster.kill()
            '''for trap in pygame.sprite.groupcollide(
                self.player, self.traps, False, True,
                pygame.sprite.collide_rect):
                self.explosions.add(Explosion(trap.x, trap.y))
                self.p1.health -= BombTrap.power'''
            #getting items from chests
            for item in pygame.sprite.groupcollide(
                self.items, self.player, False, False,
                pygame.sprite.collide_rect):
                #print (item.open)
                item.open=True
                if item.open == True:
                    item.image = pygame.transform.scale(pygame.image.load('images/openChest.png'), (40,30))
                    #image from https://www.pinterest.com/pin/575546027361184243/
                    #item.open = True


                    if self.level==1:
                        if type(self.p1)== Mage:
                            self.p1.healing = True
                        elif type(self.p1)== Gunner:
                            self.p1.reload = 10
                        elif type(self.p1) == Ninja:
                            self.p1.bombs = 10
                    elif self.level==2:
                        if type(self.p1)== Mage:
                            self.p1.firewave = True
                        elif type(self.p1)== Gunner:
                            self.p1.potion = 3
                            self.p1.reload = 15
                        elif type(self.p1) == Ninja:
                            self.p1.stars = 10
                    elif self.level==3:
                        if type(self.p1) == Mage:
                            self.p1.healing = False
                            self.p1.potion = 3
                        elif type(self.p1) == Gunner:
                            self.p1.rockets = 6
                            self.p1.reload = 20
                        elif type(self.p1) == Ninja:
                            self.p1.potion = 3
                            self.p1.stars = 20
                            self.bombs = 15
                    elif self.level==4:
                        if type(self.p1) == Mage:
                            self.p1.healing = False
                            self.p1.potion = 2
                        elif type(self.p1) == Gunner:
                            self.p1.rockets = 6
                            self.p1.reload = 20
                            self.p1.potion = 2
                        elif type(self.p1) == Ninja:
                            self.p1.potion = 2
                            self.p1.stars = 20
                            self.bombs = 15
                    elif self.level==5:
                        pass
            """for item in pygame.sprite.groupcollide(
                self.items1, self.player, False, False,
                pygame.sprite.collide_rect):
                if item.open == False:
                    item.image = pygame.transform.scale(pygame.image.load('images/closedChest.png'), (40,30))
                    item.open = True"""

    def startScreen(self, screen):
        #two buttons to go to player select and instructions from start
        screen.blit(self.startBG, self.startBGrect)
        pygame.draw.rect(screen,(220,220,0),(self.width//1.75, self.height//1.2,100, 30))
        pygame.draw.rect(screen,(220,220,0),(self.width//3.75, self.height//1.2, 100,30))
        leftButton, leftRect = self.textObjects("Start", self.smallText, (0,0,0))
        leftRect.center = (self.width//3.75+50, self.height//1.2+15)
        screen.blit(leftButton, leftRect)
        rightButton, rightRect = self.textObjects("Instructions", self.smallText, (0,0,0))
        rightRect.center = (self.width//1.75+50, self.height//1.2+15)
        screen.blit(rightButton, rightRect)
        titleText, titleRect = self.textObjects("A TIMELY RPG", self.largeText, (253,106,2))
        titleRect.center = (self.width//2, self.height//4)
        screen.blit(titleText, titleRect)

    def instructs(self, screen):
        #instructions screen
        """image = pygame.transform.scale(pygame.image.load('images/instructs.png'), (self.width, self.height))
        screen.blit(image, image.get_rect())"""
        bg = pygame.transform.scale(pygame.image.load('images/instructs.png'),(self.width, self.height-50))
        bgRect = (0,50,self.width, self.height)
        screen.blit(bg, bgRect)
        pygame.draw.rect(screen,self.backButton, (20,20,100,30))
        backButton, backRect = self.textObjects("Back", self.smallText, (0,0,0))
        backRect.center = (70, 35)
        screen.blit(backButton, backRect)

    def selectPlayer(self, screen):
        pyp = pygame.transform.scale(pygame.image.load('images/pyp.gif'), (400,50))
        screen.blit(pyp, (self.width//4-50, 75, self.width//2, 40))
        #title image from http://www.mobygames.com/game/dos/lamborghini-american-challenge/screenshots/gameShotId,3743/
        pygame.draw.line(screen, (255,255,0), (self.width//2-50,self.height//2-55),(self.width//2-100,self.height//2-75), 3)
        pygame.draw.line(screen, (255,255,0), (self.width//2-50,self.height//2+93),(self.width//2-100,self.height//2+75), 3)
        pygame.draw.line(screen, (255,255,0), (self.width//2+50,self.height//2-55),(self.width//2+100,self.height//2-75), 3)
        pygame.draw.line(screen, (255,255,0), (self.width//2+50,self.height//2+93),(self.width//2+100,self.height//2+75), 3)
        ###Mage character
        mage = pygame.transform.scale(pygame.image.load('images/mage1.png'), (100,150))
        mageRect = mage.get_rect()
        mageRect.center = (self.width//2, self.height//2+20)
        screen.blit(mage, mageRect)
        pygame.draw.rect(screen, self.select2, mageRect, 3)
        mageStats = pygame.transform.scale(pygame.image.load('images/magestats.png'), (150,100))
        mageStatsRect = (self.width//2-70, self.height*.75, 150, 100)
        screen.blit(mageStats, mageStatsRect)
        ###ninja character
        fighter = pygame.transform.scale(pygame.image.load('images/ninja1.png'), (100,150))
        fighterRect = fighter.get_rect()
        fighterRect.center = (self.width//4, self.height//2)
        screen.blit(fighter, fighterRect)
        pygame.draw.rect(screen, self.select1, fighterRect, 3)
        ninjaStats = pygame.transform.scale(pygame.image.load('images/ninjastats.png'), (150,100))
        ninjaStatsRect = (self.width//4-75, self.height*.7, 150, 100)
        screen.blit(ninjaStats, ninjaStatsRect)
        ###marksman character
        gunner = pygame.transform.scale(pygame.image.load('images/gunner1.png'), (100,150))
        gunnerRect = gunner.get_rect()
        gunnerRect.center = (self.width*.75, self.height//2)
        screen.blit(gunner, gunnerRect)
        pygame.draw.rect(screen, self.select3, gunnerRect, 3)
        gunnerStats = pygame.transform.scale(pygame.image.load('images/gunnerstats.png'), (150,100))
        gunnerStatsRect = (self.width*.75-75, self.height*.7, 150, 100)
        screen.blit(gunnerStats, gunnerStatsRect)
        ###Back Button below
        pygame.draw.rect(screen,self.backButton, (20,20,100,30))
        backButton, backRect = self.textObjects("Back", self.smallText, (0,0,0))
        backRect.center = (70, 35)
        screen.blit(backButton, backRect)

    def gameOver(self, screen):
        #game over screen
        screen.blit(self.gameOverBG, self.gameOverRect)
        restart, restartRect = self.textObjects("Press 'r' to restart", self.smallText, (255,255,255))
        restartRect.center = (self.width//2, self.height//2+50)
        screen.blit(restart, restartRect)

    def winScreen(self,screen):
        #screen when you win
        if readFile('highScore.txt')=='' or self.finishTime<int(readFile('highScore.txt')):
            print("nice")
            writeFile('highScore.txt', str(self.finishTime))
            highScore = int(readFile('highScore.txt'))
        else: highScore = int(readFile('highScore.txt'))
        bg= pygame.transform.scale(pygame.image.load('images/winBG.png'),(self.width, self.height))
        screen.blit(bg, bg.get_rect())
        time, timeRect = self.textObjects("You finished in: %d seconds, the high score is: %d" %(self.finishTime,highScore), self.smallText, (255,255,255))
        timeRect.center = (self.width//2, self.height//2+120)
        screen.blit(time, timeRect)
        restart, restartRect = self.textObjects("Press 'r' to play again for a faster time!", self.smallText, (255,255,255))
        restartRect.center = (self.width//2, self.height//2+140)
        screen.blit(restart, restartRect)
        if type(self.p1)==Mage: image = 'images/mage1.png'
        elif type(self.p1)==Gunner: image = 'images/gunner1.png'
        elif type(self.p1)==Ninja: image = 'images/ninja1.png'
        player = pygame.transform.scale(pygame.image.load(image), (100,150))
        playerRect = player.get_rect()
        playerRect.center = (self.width//2, self.height//2-50)
        screen.blit(player, playerRect)

    def gamePlay(self, screen):
        if self.level==1:
            group = self.l1Monsters
            item = pygame.sprite.Group()
            item.add(self.item1)
        elif self.level==2:
            group = self.l2Monsters
            item = pygame.sprite.Group()
            item.add(self.item2)
        elif self.level==3:
            group = self.l3Monsters
            item = pygame.sprite.Group()
            item.add(self.item3)
        elif self.level==4:
            group = self.l4Monsters
            item = pygame.sprite.Group()
        elif self.level==5:
            group = self.bossMonsters
            item = pygame.sprite.Group()
            item.add(self.item5)
        screen.blit(self.bg, self.startBGrect)
        self.levelOneMap(screen)
        self.testGrass.draw(screen)
        item.draw(screen)
        if self.p1.dir != 'down':
            self.pistolBullets.draw(screen)
            self.rockets.draw(screen)
            self.fireballs.draw(screen)
            self.stars.draw(screen)
        self.traps.draw(screen)
        self.player.draw(screen)
        group.draw(screen)
        if self.p1.dir == 'down':
            self.pistolBullets.draw(screen)
            self.rockets.draw(screen)
            self.fireballs.draw(screen)
            self.stars.draw(screen)
        self.explosions.draw(screen)
        self.Heal.draw(screen)
        
        self.statusBar(screen)
        self.inventory(screen)


    def redrawAll(self, screen):
        if self.start==True:
            self.startScreen(screen)
        if self.instructions == True:
            self.instructs(screen)
        if self.playerSelect==True:
            self.selectPlayer(screen)
        if self.level>=1 and self.lose == False:
            self.gamePlay(screen)
        if self.lose == True:
            self.gameOver(screen)
        if self.gameWon == True:
            self.winScreen(screen)

    def isKeyPressed(self, key):
        ''' return whether a specific key is being held '''
        return self._keys.get(key, False)

    def __init__(self, width=600, height=400, fps=60, title="TP"):
        self.width = width
        self.height = height
        self.fps = fps
        self.title = title
        self.bgColor = (0, 0, 0)
        pygame.init()

    def run(self):

        clock = pygame.time.Clock()
        mapScreen = pygame.display.set_mode((self.width*2, self.height*2))
        screen = pygame.display.set_mode((self.width, self.height))
        # set the title of the window
        pygame.display.set_caption(self.title)

        # stores all the keys currently being held down
        self._keys = dict()

        # call game-specific initialization
        self.init()
        playing = True
        pygame.mixer.music.load('music/bgMusic.mp3')
        #Berebere from black Panther soundtrack
        pygame.mixer.music.play(15)
        while playing:
            time = clock.tick(self.fps)
            self.timerFired(time)
            for event in pygame.event.get():
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    self.mousePressed(*(event.pos))
                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    self.mouseReleased(*(event.pos))
                elif (event.type == pygame.MOUSEMOTION and
                      event.buttons == (0, 0, 0)):
                    self.mouseMotion(*(event.pos))
                elif (event.type == pygame.MOUSEMOTION and
                      event.buttons[0] == 1):
                    self.mouseDrag(*(event.pos))
                elif event.type == pygame.KEYDOWN:
                    self._keys[event.key] = True
                    self.keyPressed(event.key, event.mod)
                elif event.type == pygame.KEYUP:
                    self._keys[event.key] = False
                    self.keyReleased(event.key, event.mod)
                elif event.type == pygame.QUIT:
                    playing = False
            screen.fill(self.bgColor)
            self.redrawAll(screen)
            pygame.display.flip()

        pygame.display.quit()
        pygame.quit()


def main():
    game = PygameGame()
    game.run()

if __name__ == '__main__':
    main()
